class Wall {
    constructor(xCoord, yCoord, width, height, radius)  {
      this.xCoord = xCoord;
      this.yCoord = yCoord;
      this.width = width;
      this.height = height;
      this.radius = radius;
    }
} 